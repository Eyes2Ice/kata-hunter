import { Tabs } from "@mantine/core";
import styles from "./Jobs.module.css";
import { useTypedDispatch, useTypedSelector } from "@/hooks/redux";
import { setCity } from "@/reducers/JobsSlice";

export default function JobsLocation() {
  const city = useTypedSelector((state) => state.jobsReducer.city);
  const dispatch = useTypedDispatch();
  const handleChange = (value: string | null) => {
    dispatch(setCity(value));
  };

  return (
    <Tabs
      onChange={handleChange}
      value={city}
      className={styles.jobs__tabs}
      color="#4263eb"
    >
      <Tabs.List justify="center" component="ul">
        <Tabs.Tab value="Москва">Москва</Tabs.Tab>
        <Tabs.Tab value="Санкт-Петербург">Санкт-Петербург</Tabs.Tab>
      </Tabs.List>
    </Tabs>
  );
}

// Допилить изначальное состояние URL
// Сделать Nested Routes для табов
