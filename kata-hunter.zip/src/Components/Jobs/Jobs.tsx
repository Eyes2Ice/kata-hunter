import { Box, Container, Divider, Group } from "@mantine/core";
import JobsHeader from "./JobsHeader";
import JobsSkills from "./JobsSkills";
import JobsList from "./JobsList";
import { useJobsSearchParams } from "@/hooks/useJobsSearchParams";

import styles from "./Jobs.module.css";
import JobsLocation from "./JobsLocation";

export default function Jobs() {
  useJobsSearchParams();

  return (
    <main>
      <Box component="section" className="jobs">
        <Box className="jobs__inner">
          <JobsHeader />
          <Divider color="#0f0f1033" opacity={0.2}></Divider>
          <Container size={1000}>
            <JobsLocation />
            <Group className={styles.jobs__body}>
              <JobsSkills />
              <JobsList />
            </Group>
          </Container>
        </Box>
      </Box>
    </main>
  );
}
