import { Box, Group, Image, Text, NavLink } from "@mantine/core";
import logo from "@/assets/img/logo/logo.png";
import { Link } from "react-router-dom";

export default function Header() {
  return (
    <Box component="header" className="header">
      <Group className="header__inner">
        <Link to="/" className="logo">
          <Image src={logo} className="logo__image"></Image>
          <Text fw={600} lh={1.5} className="logo__text">
            .FrontEnd
          </Text>
        </Link>
        <Group component="nav" className="nav header__nav">
          <NavLink href="#" label="Вакансии FE" className="nav__link" active />
          <NavLink
            href="#"
            label="Обо мне"
            className="nav__link"
            leftSection={
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M6.16797 18.849C6.41548 18.0252 6.92194 17.3032 7.61222 16.79C8.30249 16.2768 9.13982 15.9997 9.99997 16H14C14.8612 15.9997 15.6996 16.2774 16.3904 16.7918C17.0811 17.3062 17.5874 18.0298 17.834 18.855M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12ZM15 10C15 11.6569 13.6569 13 12 13C10.3431 13 9 11.6569 9 10C9 8.34315 10.3431 7 12 7C13.6569 7 15 8.34315 15 10Z"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            }
          />
        </Group>
      </Group>
    </Box>
  );
}
