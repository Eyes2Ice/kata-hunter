import "./App.css";
import Layout from "./Components/Layout/Layout";
import {
  createHashRouter,
  createRoutesFromElements,
  Route,
} from "react-router-dom";
import HomePage from "./pages/home";
import SingleJobPage from "./pages/single-job";
import { RouterProvider } from "react-router";
import Pagenotfound from "./pages/404";

const router = createHashRouter(
  createRoutesFromElements(
    <Route
      path="/"
      element={<Layout />}
      errorElement={<h1>Something goes wrong!</h1>}
    >
      <Route index element={<HomePage />} />
      <Route path="vacancies/moscow" element={<h1>Avavav</h1>} />
      <Route path="vacancies/petersburg " element={<h1>Qweqwe</h1>} />
      <Route path="vacancies/:id" element={<SingleJobPage />} />
      <Route path="*" element={<Pagenotfound />} />
    </Route>,
  ),
);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
